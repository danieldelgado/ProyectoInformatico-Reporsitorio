package com.student;

import java.io.IOException;

import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderMode;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.student.services.model.Student;
import com.student.services.service.StudentLocalServiceUtil;

/**
 * Portlet implementation class SeachContainer
 */
public class SeachContainer extends GenericPortlet {
	 @RenderMode(name="VIEW")
	    public void myView(RenderRequest renderRequest, RenderResponse renderResponse) throws IOException, PortletException {
		       String value  = renderRequest.getParameter("click");
		       PortletRequestDispatcher portletRequestDispatcher;
		       if(value!=null)
		       {
		    	   int studentId = Integer.parseInt(renderRequest.getParameter("studentId"));
		    	   try {
					Student student = StudentLocalServiceUtil.getStudent(studentId);
					renderRequest.setAttribute("student", student);
				} catch (Exception e) {
					e.printStackTrace();
				} 
		    	   
		    	   portletRequestDispatcher = getPortletContext().getRequestDispatcher("/html/seachcontainer/display_student.jsp");	
		           portletRequestDispatcher.include(renderRequest, renderResponse); 
		       }
		       else{
		        portletRequestDispatcher = getPortletContext().getRequestDispatcher("/html/seachcontainer/view.jsp");	
	        	portletRequestDispatcher.include(renderRequest, renderResponse);
		       }
	    	
	    	      
	    }
   
}
