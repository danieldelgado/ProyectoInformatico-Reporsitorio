create table student (
	studentId INTEGER not null primary key,
	name VARCHAR(75) null,
	lastname VARCHAR(75) null,
	std VARCHAR(75) null,
	address VARCHAR(75) null,
	phone VARCHAR(75) null,
	gender INTEGER
);