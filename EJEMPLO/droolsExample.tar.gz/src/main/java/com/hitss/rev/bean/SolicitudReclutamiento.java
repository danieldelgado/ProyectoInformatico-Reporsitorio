package com.hitss.rev.bean;

import java.util.Date;

public class SolicitudReclutamiento {

	
	private long id;
	private PuestoBean puesto;
	private Date fechaLimite;
	private String strfechaLimite;
	private Date fechaRegistro;
	private String strfechaRegistro;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public PuestoBean getPuesto() {
		return puesto;
	}
	public void setPuesto(PuestoBean puesto) {
		this.puesto = puesto;
	}
	public Date getFechaLimite() {
		return fechaLimite;
	}
	public void setFechaLimite(Date fechaLimite) {
		this.fechaLimite = fechaLimite;
	}
	public String getStrfechaLimite() {
		return strfechaLimite;
	}
	public void setStrfechaLimite(String strfechaLimite) {
		this.strfechaLimite = strfechaLimite;
	}
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getStrfechaRegistro() {
		return strfechaRegistro;
	}
	public void setStrfechaRegistro(String strfechaRegistro) {
		this.strfechaRegistro = strfechaRegistro;
	}
	
	
	
}
