package com.hitss.rev.bean;

import java.util.Date;

public class Postulacion {

	
	private SolicitudReclutamiento solicitudReclutamiento;
	private UsuarioBean usuarioBean;
	private Date fechaPostulacion;
	private String strfechaPostulacion;
	
	public SolicitudReclutamiento getSolicitudReclutamiento() {
		return solicitudReclutamiento;
	}
	public void setSolicitudReclutamiento(
			SolicitudReclutamiento solicitudReclutamiento) {
		this.solicitudReclutamiento = solicitudReclutamiento;
	}
	public UsuarioBean getUsuarioBean() {
		return usuarioBean;
	}
	public void setUsuarioBean(UsuarioBean usuarioBean) {
		this.usuarioBean = usuarioBean;
	}
	public Date getFechaPostulacion() {
		return fechaPostulacion;
	}
	public void setFechaPostulacion(Date fechaPostulacion) {
		this.fechaPostulacion = fechaPostulacion;
	}
	public String getStrfechaPostulacion() {
		return strfechaPostulacion;
	}
	public void setStrfechaPostulacion(String strfechaPostulacion) {
		this.strfechaPostulacion = strfechaPostulacion;
	}

	
	
}
