package com.hitss.rev.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InicializarData {

	public static Date getFechaDate(String date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try {
			return sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public PuestoBean getPuestoProgramadorJavaJunior() {
		PuestoBean p = new PuestoBean();
		p.setId(1L);
		p.setNombre("Programador Java Junior");
		p.setPresupuestoMaximo(1200);
		p.setPresupuestoMinimo(1000);
		p.setTipoNegocioRequierido(ExperienciaBean.EXPERIENCIA_NINGUNO);		
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 2, false);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean2 = new RequisitoBean(2L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Spring", 1, false);
			listaRequisitoBean.add(requisitoBean2);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 1, false);
			listaRequisitoBean.add(requisitoBean3);
			RequisitoBean requisitoBean4 = new RequisitoBean(4L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Jquery", 1, false);
			listaRequisitoBean.add(requisitoBean4);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			p.setListaCertificados(listaCertificados);
		}	
		{
			List<EvaluacionPuestoBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean = new EvaluacionPuestoBean(1L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_01, "evluacion01", 0.1, 0.2);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionPuestoBean evaluacionPuestoBean2 = new EvaluacionPuestoBean(2L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_02, "evluacion02", 0, 0.1);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionPuestoBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean3 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_TECNICA_01, "evluacion tecnica 01", 0.4, 0.8);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionPuestoBean evaluacionPuestoBean4 = new EvaluacionPuestoBean(4L, EvaluacionPuestoBean.EVALUAION_TECNICA_02, "evluacion tecnica 02", 0.4, 0.8);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionPuestoBean> listaEntrevista = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean5 = new EvaluacionPuestoBean(5L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, "entrevista coordinador", 0.4, 0.8);
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionPuestoBean evaluacionPuestoBean6 = new EvaluacionPuestoBean(6L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_GERENTE_AREA, "entrevista gerente", 0.4, 0.8);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		return p;
	}

	public PuestoBean getPuestoProgramadorJavaSemiSenior() {
		PuestoBean p = new PuestoBean();
		p.setId(2L);
		p.setNombre("Programador Java Semi Senior");
		p.setPresupuestoMaximo(2000);
		p.setPresupuestoMinimo(1200);
		p.setTipoNegocioRequierido(ExperienciaBean.EXPERIENCIA_BANCA);
		{
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, ExperienciaBean.EXPERIENCIA_BANCA, 2);
			p.setExperienciaRubro(experienciaBean);
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 4, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean2 = new RequisitoBean(2L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Spring", 3, true);
			listaRequisitoBean.add(requisitoBean2);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 3, true);
			listaRequisitoBean.add(requisitoBean3);
			RequisitoBean requisitoBean4 = new RequisitoBean(4L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Jquery", 3, false);
			listaRequisitoBean.add(requisitoBean4);
			RequisitoBean requisitoBean5 = new RequisitoBean(5L, RequisitoBean.REQUISITO_CONOCIMIENTO, "JSF", 4, true);
			listaRequisitoBean.add(requisitoBean5);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean6 = new RequisitoBean(6L, RequisitoBean.REQUISITO_CERTIFICADO, "Java 7", true);
			listaCertificados.add(requisitoBean6);
			p.setListaCertificados(listaCertificados);
		}		
		{
			List<EvaluacionPuestoBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean = new EvaluacionPuestoBean(1L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_01, "evluacion01", 0.3, 0.4);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionPuestoBean evaluacionPuestoBean2 = new EvaluacionPuestoBean(2L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_02, "evluacion02", 0.1, 0.2);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionPuestoBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean3 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_TECNICA_01, "evluacion tecnica 01", 0.6, 0.8);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionPuestoBean evaluacionPuestoBean4 = new EvaluacionPuestoBean(4L, EvaluacionPuestoBean.EVALUAION_TECNICA_02, "evluacion tecnica 02", 0.6, 0.8);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionPuestoBean> listaEntrevista = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean5 = new EvaluacionPuestoBean(5L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, "entrevista coordinador", 0.4, 0.6);
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionPuestoBean evaluacionPuestoBean6 = new EvaluacionPuestoBean(6L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_GERENTE_AREA, "entrevista gerente", 0.4, 0.6);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		return p;
	}

	public PuestoBean getPuestoProgramadorJavaSenior() {
		PuestoBean p = new PuestoBean();
		p.setId(3L);
		p.setNombre("Programador Java Senior");
		p.setPresupuestoMaximo(3000);
		p.setPresupuestoMinimo(2000);
		p.setTipoNegocioRequierido(ExperienciaBean.EXPERIENCIA_FINANZA);
		{
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, ExperienciaBean.EXPERIENCIA_FINANZA, 2);
			p.setExperienciaRubro(experienciaBean);
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 5, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean2 = new RequisitoBean(2L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Spring", 5, true);
			listaRequisitoBean.add(requisitoBean2);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 5, true);
			listaRequisitoBean.add(requisitoBean3);
			RequisitoBean requisitoBean4 = new RequisitoBean(4L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Jquery", 5, true);
			listaRequisitoBean.add(requisitoBean4);
			RequisitoBean requisitoBean5 = new RequisitoBean(5L, RequisitoBean.REQUISITO_CONOCIMIENTO, "JSF", 5, true);
			listaRequisitoBean.add(requisitoBean5);
			RequisitoBean requisitoBean7 = new RequisitoBean(7L, RequisitoBean.REQUISITO_CONOCIMIENTO, "STRUS", 5, true);
			listaRequisitoBean.add(requisitoBean7);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Liferay", 5, true);
			listaRequisitoBean.add(requisitoBean8);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean6 = new RequisitoBean(6L, RequisitoBean.REQUISITO_CERTIFICADO, "Java 7", true);
			listaCertificados.add(requisitoBean6);
			p.setListaCertificados(listaCertificados);
		}		
		{
			List<EvaluacionPuestoBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean = new EvaluacionPuestoBean(1L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_01, "evluacion01", 0.7, 0.9);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionPuestoBean evaluacionPuestoBean2 = new EvaluacionPuestoBean(2L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_02, "evluacion02", 0.5, 0.6);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionPuestoBean evaluacionPuestoBean8 = new EvaluacionPuestoBean(8L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_04, "evluacion04", 0.3, 0.5);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean8);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionPuestoBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean3 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_TECNICA_01, "evluacion tecnica 01", 0.7, 0.97);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionPuestoBean evaluacionPuestoBean4 = new EvaluacionPuestoBean(4L, EvaluacionPuestoBean.EVALUAION_TECNICA_02, "evluacion tecnica 02", 0.7, 0.97);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionPuestoBean evaluacionPuestoBean7 = new EvaluacionPuestoBean(7L, EvaluacionPuestoBean.EVALUAION_TECNICA_03, "evluacion tecnica 03", 0.7, 0.97);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean7);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionPuestoBean> listaEntrevista = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean5 = new EvaluacionPuestoBean(5L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, "entrevista coordinador", 0.7, 0.95);
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionPuestoBean evaluacionPuestoBean6 = new EvaluacionPuestoBean(6L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_GERENTE_AREA, "entrevista gerente", 0.7, 0.95);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		return p;
	}

	public PuestoBean getPuestoAnalistaProgramador() {
		PuestoBean p = new PuestoBean();
		p.setId(3L);
		p.setNombre("Analista Programador");
		p.setPresupuestoMaximo(3000);
		p.setPresupuestoMinimo(2000);
		p.setTipoNegocioRequierido(ExperienciaBean.EXPERIENCIA_FINANZA);
		{
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, ExperienciaBean.EXPERIENCIA_FINANZA, 1);
			p.setExperienciaRubro(experienciaBean);
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 4, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean2 = new RequisitoBean(2L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Spring", 3, false);
			listaRequisitoBean.add(requisitoBean2);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 3, false);
			listaRequisitoBean.add(requisitoBean3);
			RequisitoBean requisitoBean4 = new RequisitoBean(4L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Jquery", 3, false);
			listaRequisitoBean.add(requisitoBean4);
			RequisitoBean requisitoBean5 = new RequisitoBean(5L, RequisitoBean.REQUISITO_CONOCIMIENTO, "JSF", 2, false);
			listaRequisitoBean.add(requisitoBean5);
			RequisitoBean requisitoBean7 = new RequisitoBean(7L, RequisitoBean.REQUISITO_CONOCIMIENTO, "STRUS", 2, false);
			listaRequisitoBean.add(requisitoBean7);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 2, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 3, false);
			listaRequisitoBean.add(requisitoBean10);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			
			p.setListaCertificados(listaCertificados);
		}		
		{
			List<EvaluacionPuestoBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean = new EvaluacionPuestoBean(1L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_01, "evluacion01", 0.7, 0.9);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionPuestoBean evaluacionPuestoBean2 = new EvaluacionPuestoBean(2L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_02, "evluacion02", 0.5, 0.6);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionPuestoBean evaluacionPuestoBean8 = new EvaluacionPuestoBean(8L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_04, "evluacion04", 0.3, 0.5);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean8);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionPuestoBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean3 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_TECNICA_01, "evluacion tecnica 01", 0.6, 0.7);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionPuestoBean evaluacionPuestoBean4 = new EvaluacionPuestoBean(4L, EvaluacionPuestoBean.EVALUAION_TECNICA_02, "evluacion tecnica 02", 0.3, 0.5);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionPuestoBean evaluacionPuestoBean7 = new EvaluacionPuestoBean(7L, EvaluacionPuestoBean.EVALUAION_TECNICA_03, "evluacion tecnica 03", 0.4, 0.5);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean7);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionPuestoBean> listaEntrevista = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean5 = new EvaluacionPuestoBean(5L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, "entrevista coordinador", 0.7, 0.8);
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionPuestoBean evaluacionPuestoBean6 = new EvaluacionPuestoBean(6L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_GERENTE_AREA, "entrevista gerente", 0.7, 0.8);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		return p;
	}

	public PuestoBean getPuestoAnalista() {
		PuestoBean p = new PuestoBean();
		p.setId(3L);
		p.setNombre("Analista");
		p.setPresupuestoMaximo(3000);
		p.setPresupuestoMinimo(2000);
		{
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, ExperienciaBean.EXPERIENCIA_FINANZA, 3);
			p.setExperienciaRubro(experienciaBean);
		}
		{
			p.setTipoNegocioRequierido(ExperienciaBean.EXPERIENCIA_FINANZA);
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 3, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 5, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 4, false);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 4, false);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4, false);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			
			p.setListaCertificados(listaCertificados);
		}		
		{
			List<EvaluacionPuestoBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean = new EvaluacionPuestoBean(1L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_01, "evluacion01", 0.3, 0.4);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionPuestoBean evaluacionPuestoBean2 = new EvaluacionPuestoBean(2L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_02, "evluacion02", 0.5, 0.6);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionPuestoBean evaluacionPuestoBean8 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_04, "evluacion04", 0.3, 0.5);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean8);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionPuestoBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean3 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_TECNICA_01, "evluacion tecnica 01", 0.4, 0.55);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionPuestoBean evaluacionPuestoBean4 = new EvaluacionPuestoBean(4L, EvaluacionPuestoBean.EVALUAION_TECNICA_02, "evluacion tecnica 02", 0.2, 0.3);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionPuestoBean evaluacionPuestoBean8 = new EvaluacionPuestoBean(8L, EvaluacionPuestoBean.EVALUAION_TECNICA_04, "evluacion tecnica 03", 0.6, 0.7);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean8);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionPuestoBean> listaEntrevista = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean5 = new EvaluacionPuestoBean(5L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, "entrevista coordinador", 0.7, 0.8);
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionPuestoBean evaluacionPuestoBean6 = new EvaluacionPuestoBean(6L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_GERENTE_AREA, "entrevista gerente", 0.7, 0.8);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		return p;
	}

	public PuestoBean getPuestoGerente() {
		PuestoBean p = new PuestoBean();
		p.setId(3L);
		p.setNombre("Gerente");
		p.setPresupuestoMaximo(9000);
		p.setPresupuestoMinimo(8000);
		p.setTipoNegocioRequierido(ExperienciaBean.EXPERIENCIA_BOLSA);
		{
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, ExperienciaBean.EXPERIENCIA_BOLSA, 4);
			p.setExperienciaRubro(experienciaBean);
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean14 = new RequisitoBean(14L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Gestion de Proyectos", 5, true);
			listaRequisitoBean.add(requisitoBean14);
			RequisitoBean requisitoBean15 = new RequisitoBean(15L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Project", 5, false);
			listaRequisitoBean.add(requisitoBean15);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 5, true);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 5, true);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(13L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum",4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean16 = new RequisitoBean(16L, RequisitoBean.REQUISITO_CERTIFICADO, "PMBOOK",true);
			listaCertificados.add(requisitoBean16);
			RequisitoBean requisitoBean17 = new RequisitoBean(16L, RequisitoBean.REQUISITO_CERTIFICADO, "PMI",true);
			listaCertificados.add(requisitoBean17);
			p.setListaCertificados(listaCertificados);
		}		
		{
			List<EvaluacionPuestoBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean = new EvaluacionPuestoBean(1L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_01, "evluacion01", 0.7, 0.95);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionPuestoBean evaluacionPuestoBean2 = new EvaluacionPuestoBean(2L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_02, "evluacion02", 0.8, 0.95);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionPuestoBean evaluacionPuestoBean8 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_PSICOLOGICA_04, "evluacion04", 0.9, 0.95);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean8);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionPuestoBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean3 = new EvaluacionPuestoBean(3L, EvaluacionPuestoBean.EVALUAION_TECNICA_01, "evluacion tecnica 01", 0.4, 0.55);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);			
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionPuestoBean> listaEntrevista = new ArrayList<EvaluacionPuestoBean>();
			EvaluacionPuestoBean evaluacionPuestoBean5 = new EvaluacionPuestoBean(5L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, "entrevista coordinador", 0.9, 0.95);
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionPuestoBean evaluacionPuestoBean6 = new EvaluacionPuestoBean(6L, EvaluacionPuestoBean.EVALUAION_ENTREVISTA_GERENTE_AREA, "entrevista gerente", 0.8, 0.95);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		return p;
	}


	public UsuarioBean getUsuarioPostulante01() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(1L);
		p.setNombre("Usuario 01");
		p.setSalario(1000);
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 1, false);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 1, false);
			listaRequisitoBean.add(requisitoBean3);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			p.setListaCertificados(listaCertificados);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  14);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 15);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 15 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}
	
	public UsuarioBean getUsuarioPostulante02() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(1L);
		p.setNombre("Usuario 01");
		p.setSalario(1000);
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 1, false);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 1, false);
			listaRequisitoBean.add(requisitoBean3);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			p.setListaCertificados(listaCertificados);
		}
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 3, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 5, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 4, false);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 4, false);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4, false);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  14);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  13);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 15);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 15 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}
	
	public UsuarioBean getUsuarioPostulante03() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(1L);
		p.setNombre("Usuario 01");
		p.setSalario(1000);
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 1, false);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 1, false);
			listaRequisitoBean.add(requisitoBean3);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			p.setListaCertificados(listaCertificados);
		}
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 3, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 5, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 4, false);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 4, false);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4, false);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  14);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  13);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 15);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 15 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}

	public UsuarioBean getUsuarioPostulante04() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(1L);
		p.setNombre("Usuario 01");
		p.setSalario(1000);
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 1, false);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 1, false);
			listaRequisitoBean.add(requisitoBean3);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			p.setListaCertificados(listaCertificados);
		}
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 3, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 5, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 4, false);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 4, false);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4, false);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  14);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  13);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 15);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 15 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}

	public UsuarioBean getUsuarioPostulante05() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(1L);
		p.setNombre("Usuario 01");
		p.setSalario(1000);
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 1, false);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean3 = new RequisitoBean(3L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Mysql", 1, false);
			listaRequisitoBean.add(requisitoBean3);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			p.setListaCertificados(listaCertificados);
		}
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 3, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 5, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 4, false);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 4, false);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4, false);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  14);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  13);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 15);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 15 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}

	public UsuarioBean getUsuarioPostulante06() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(6L);
		p.setNombre("Usuario 01");
		p.setSalario(2800);		
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 5);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML",2);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 3);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 3);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 5);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 5);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  14);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  13);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 19);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 20);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 18);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 18 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}

	public UsuarioBean getUsuarioPostulante07() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(7L);
		p.setNombre("Usuario 01");
		p.setSalario(2500);
		
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 3, true);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 4, true);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 5, true);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 4, false);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 4, false);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4, false);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4, false);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 16);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  19);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  15);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 19);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 20);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 16 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 18);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}

	public UsuarioBean getUsuarioPostulante08() {
		UsuarioBean p = new UsuarioBean();
		p.setIdUsuario(8L);
		p.setNombre("Usuario 01");
		p.setSalario(3200);
		{
			List<RequisitoBean> listaRequisitoBean = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Java", 5);
			listaRequisitoBean.add(requisitoBean);
			RequisitoBean requisitoBean8 = new RequisitoBean(8L, RequisitoBean.REQUISITO_CONOCIMIENTO, "UML", 1);
			listaRequisitoBean.add(requisitoBean8);
			RequisitoBean requisitoBean9 = new RequisitoBean(9L, RequisitoBean.REQUISITO_CONOCIMIENTO, "RUP", 2);
			listaRequisitoBean.add(requisitoBean9);
			RequisitoBean requisitoBean10 = new RequisitoBean(10L, RequisitoBean.REQUISITO_CONOCIMIENTO, "ERWIN", 3);
			listaRequisitoBean.add(requisitoBean10);
			RequisitoBean requisitoBean11 = new RequisitoBean(11L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias de desarrollo", 3);
			listaRequisitoBean.add(requisitoBean11);
			RequisitoBean requisitoBean12 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Metodologias agiles", 4);
			listaRequisitoBean.add(requisitoBean12);
			RequisitoBean requisitoBean13 = new RequisitoBean(12L, RequisitoBean.REQUISITO_CONOCIMIENTO, "Scrum", 4);
			listaRequisitoBean.add(requisitoBean13);
			p.setListaConocimientos(listaRequisitoBean);
		}
		{
			List<RequisitoBean> listaCertificados = new ArrayList<RequisitoBean>();
			RequisitoBean requisitoBean = new RequisitoBean(1L, RequisitoBean.REQUISITO_CERTIFICADO, "Java 7");
			listaCertificados.add(requisitoBean);
			RequisitoBean requisitoBean2 = new RequisitoBean(2L, RequisitoBean.REQUISITO_CERTIFICADO, "UML");
			listaCertificados.add(requisitoBean2);
			p.setListaCertificados(listaCertificados);
		}
		{
			List<ExperienciaBean> listaExperiencias = new ArrayList<ExperienciaBean>();
			ExperienciaBean experienciaBean = new ExperienciaBean(1L, "emp1", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean);
			ExperienciaBean experienciaBean2 = new ExperienciaBean(2L, "emp2", ExperienciaBean.EXPERIENCIA_FINANZA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean2);
			ExperienciaBean experienciaBean3 = new ExperienciaBean(3L, "emp3", ExperienciaBean.EXPERIENCIA_BANCA, "proy1", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean3);
			ExperienciaBean experienciaBean4 = new ExperienciaBean(4L, "emp4", ExperienciaBean.EXPERIENCIA_BANCA, "proy3", getFechaDate("10/10/2014"), getFechaDate("10/10/2015"));
			listaExperiencias.add(experienciaBean4);
			p.setListaExperiencias(listaExperiencias);			
		}
		{
			List<EvaluacionBean> listaEvaluacionPiscologicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean = new EvaluacionBean(1L, EvaluacionBean.EVALUAION_PSICOLOGICA_01, 17);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_02,  20);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean2);
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(2L, EvaluacionBean.EVALUAION_PSICOLOGICA_03,  19);
			listaEvaluacionPiscologicas.add(evaluacionPuestoBean3);
			p.setListaEvaluacionPiscologicas(listaEvaluacionPiscologicas);
		}
		{
			List<EvaluacionBean> listaEvaluacionTecnicas = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean3 = new EvaluacionBean(3L, EvaluacionBean.EVALUAION_TECNICA_01, 16);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean3);
			EvaluacionBean evaluacionPuestoBean4 = new EvaluacionBean(4L, EvaluacionBean.EVALUAION_TECNICA_02, 19);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean4);
			EvaluacionBean evaluacionPuestoBean2 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_TECNICA_03, 20);
			listaEvaluacionTecnicas.add(evaluacionPuestoBean2);
			p.setListaEvaluacionTecnicas(listaEvaluacionTecnicas);
		}
		{
			List<EvaluacionBean> listaEntrevista = new ArrayList<EvaluacionBean>();
			EvaluacionBean evaluacionPuestoBean5 = new EvaluacionBean(5L, EvaluacionBean.EVALUAION_ENTREVISTA_COORDINADOR_RRHH, 15 );
			listaEntrevista.add(evaluacionPuestoBean5);
			EvaluacionBean evaluacionPuestoBean6 = new EvaluacionBean(6L, EvaluacionBean.EVALUAION_ENTREVISTA_GERENTE_AREA, 17);
			listaEntrevista.add(evaluacionPuestoBean6);
			p.setListaEntrevista(listaEntrevista);
		}
		
		return p;
	}

}
