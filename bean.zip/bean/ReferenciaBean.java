package com.hitss.rev.bean;

public class ReferenciaBean {

}
